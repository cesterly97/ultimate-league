const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true, game: "Ultimate League Slots" }));

// Prototype only: rooms and credits live in memory and reset on server restart.
// Every wager, spin result, contribution, and payout is calculated on the server.
const rooms = new Map();
const wallets = new Map();
const symbols = ["🍒", "🍋", "🔔", "💎", "7️⃣", "👑"];
const weights = [28, 24, 20, 14, 9, 5];
const multipliers = { "🍒": 2, "🍋": 2, "🔔": 3, "💎": 5, "7️⃣": 10, "👑": 20 };

function wallet(id) {
  if (!wallets.has(id)) wallets.set(id, { credits: 1000 });
  return wallets.get(id);
}
function code() { return crypto.randomBytes(3).toString("hex").toUpperCase(); }
function weightedSymbol() {
  let n = Math.random() * weights.reduce((a,b)=>a+b,0);
  for (let i=0;i<symbols.length;i++) { n -= weights[i]; if (n <= 0) return symbols[i]; }
  return symbols[0];
}
function publicRoom(room) {
  return {
    code: room.code, hostId: room.hostId, phase: room.phase,
    players: [...room.players.values()].map(p => ({
      id: p.id, name: p.name, credits: wallet(p.id).credits,
      contribution: p.contribution, sharePct: p.sharePct, ready: p.ready
    })),
    pot: room.pot, lastSpin: room.lastSpin, message: room.message,
    round: room.round, maxPlayers: 8
  };
}
function emitRoom(room) { io.to(room.code).emit("room:update", publicRoom(room)); }
function sendError(socket, message) { socket.emit("game:error", message); }
function findRoomByPlayer(id) {
  for (const room of rooms.values()) if (room.players.has(id)) return room;
  return null;
}
function normalizeName(n) { return String(n || "Player").trim().replace(/[<>]/g,"").slice(0,18) || "Player"; }

io.on("connection", socket => {
  wallet(socket.id);
  socket.emit("wallet:update", wallet(socket.id));

  socket.on("room:create", ({ name } = {}) => {
    if (findRoomByPlayer(socket.id)) return sendError(socket, "Leave your current room first.");
    let roomCode = code();
    while (rooms.has(roomCode)) roomCode = code();
    const room = {
      code: roomCode, hostId: socket.id, phase: "lobby", players: new Map(),
      pot: 0, lastSpin: null, message: "Invite a friend, set your shares, then spin together.",
      round: 0
    };
    room.players.set(socket.id, { id: socket.id, name: normalizeName(name), contribution: 50, sharePct: 50, ready: true });
    rooms.set(roomCode, room);
    socket.join(roomCode);
    socket.emit("room:joined", { code: roomCode });
    emitRoom(room);
  });

  socket.on("room:join", ({ code: rawCode, name } = {}) => {
    if (findRoomByPlayer(socket.id)) return sendError(socket, "Leave your current room first.");
    const room = rooms.get(String(rawCode || "").toUpperCase().trim());
    if (!room) return sendError(socket, "Room not found. Check the code and try again.");
    if (room.players.size >= 8) return sendError(socket, "This room is full (8 players maximum).");
    if (room.phase === "spinning") return sendError(socket, "That room is spinning. Try again after the round.");
    room.players.set(socket.id, { id: socket.id, name: normalizeName(name), contribution: 50, sharePct: 50, ready: true });
    socket.join(room.code);
    room.message = `${normalizeName(name)} joined the team.`;
    socket.emit("room:joined", { code: room.code });
    emitRoom(room);
  });

  socket.on("room:leave", () => {
    const room = findRoomByPlayer(socket.id);
    if (!room) return;
    room.players.delete(socket.id);
    socket.leave(room.code);
    if (!room.players.size) rooms.delete(room.code);
    else {
      if (room.hostId === socket.id) room.hostId = room.players.keys().next().value;
      room.message = "A player left the team.";
      emitRoom(room);
    }
  });

  socket.on("solo:spin", ({ bet } = {}) => {
    if (findRoomByPlayer(socket.id)) return sendError(socket, "Leave the team room to play solo.");
    const amount = Number(bet);
    if (!Number.isInteger(amount) || amount < 1 || amount > 100) return sendError(socket, "Choose a whole-number bet from 1 to 100 credits.");
    const w = wallet(socket.id);
    if (w.credits < amount) return sendError(socket, "Not enough credits. Use the reset button for demo credits.");
    w.credits -= amount;
    const reels = [weightedSymbol(), weightedSymbol(), weightedSymbol()];
    let multiplier = 0;
    if (reels.every(s => s === reels[0])) multiplier = multipliers[reels[0]] * 5;
    else if (reels[0] === reels[1] || reels[1] === reels[2] || reels[0] === reels[2]) multiplier = multipliers[reels.find((s,i)=>reels.indexOf(s)!==i)] || 2;
    const payout = amount * multiplier;
    w.credits += payout;
    socket.emit("solo:result", { reels, bet: amount, payout, net: payout-amount, credits: w.credits, multiplier });
    socket.emit("wallet:update", w);
  });

  socket.on("team:configure", ({ shares, contributions } = {}) => {
    const room = findRoomByPlayer(socket.id);
    if (!room) return sendError(socket, "Join a team room first.");
    if (room.hostId !== socket.id) return sendError(socket, "Only the room host can configure the team.");
    if (room.phase === "spinning") return sendError(socket, "Wait for the spin to finish.");
    const players = [...room.players.values()];
    if (!Array.isArray(shares) || shares.length !== players.length || !Array.isArray(contributions) || contributions.length !== players.length)
      return sendError(socket, "Share settings did not match the players in the room.");
    if (shares.some(n => !Number.isInteger(Number(n)) || Number(n) < 0) || shares.reduce((s,n)=>s+Number(n),0)!==100)
      return sendError(socket, "Payout shares must be whole percentages adding up to exactly 100%.");
    if (contributions.some(n => !Number.isInteger(Number(n)) || Number(n) < 1 || Number(n) > 100))
      return sendError(socket, "Each player's contribution must be 1–100 credits per spin.");
    players.forEach((p,i) => { p.sharePct = Number(shares[i]); p.contribution = Number(contributions[i]); });
    room.message = "Team shares saved. Payouts will be split by these percentages.";
    emitRoom(room);
  });

  socket.on("team:spin", () => {
    const room = findRoomByPlayer(socket.id);
    if (!room) return sendError(socket, "Join a team room first.");
    if (room.hostId !== socket.id) return sendError(socket, "Only the host can start the shared spin.");
    if (room.phase === "spinning") return sendError(socket, "A spin is already in progress.");
    const players = [...room.players.values()];
    if (players.length < 2) return sendError(socket, "Invite at least one friend to spin as a team.");
    if (players.reduce((s,p)=>s+p.sharePct,0)!==100) return sendError(socket, "Team payout shares must total 100%.");
    for (const p of players) if (wallet(p.id).credits < p.contribution) return sendError(socket, `${p.name} does not have enough credits for their contribution.`);
    players.forEach(p => { wallet(p.id).credits -= p.contribution; });
    const wager = players.reduce((s,p)=>s+p.contribution,0);
    room.pot = wager;
    room.phase = "spinning";
    room.round++;
    room.message = "The team is spinning…";
    emitRoom(room);

    setTimeout(() => {
      if (!rooms.has(room.code)) return;
      const reels = [weightedSymbol(), weightedSymbol(), weightedSymbol()];
      let multiplier = 0;
      if (reels.every(s => s === reels[0])) multiplier = multipliers[reels[0]] * 5;
      else if (reels[0] === reels[1] || reels[1] === reels[2] || reels[0] === reels[2]) {
        const pair = reels[0] === reels[1] ? reels[0] : reels[1] === reels[2] ? reels[1] : reels[0];
        multiplier = multipliers[pair];
      }
      const payout = wager * multiplier;
      const allocations = players.map(p => {
        const exact = payout * p.sharePct / 100;
        return { id: p.id, name: p.name, sharePct: p.sharePct, payout: Math.floor(exact) };
      });
      // Give any rounding remainder to the host, ensuring allocated credits equal the payout.
      const allocated = allocations.reduce((s,a)=>s+a.payout,0);
      if (allocations.length) allocations.find(a=>a.id===room.hostId).payout += payout-allocated;
      allocations.forEach(a => { wallet(a.id).credits += a.payout; });
      room.lastSpin = { reels, wager, payout, multiplier, allocations, round: room.round };
      room.pot = 0;
      room.phase = "lobby";
      room.message = payout ? `Team win! ${payout} credits paid out by your agreed percentages.` : "No win this spin. Your team can try again.";
      emitRoom(room);
      for (const p of players) io.to(p.id).emit("wallet:update", wallet(p.id));
    }, 1500);
  });

  socket.on("wallet:reset", () => {
    if (findRoomByPlayer(socket.id)) return sendError(socket, "Leave your room before resetting demo credits.");
    wallets.set(socket.id, { credits: 1000 });
    socket.emit("wallet:update", wallet(socket.id));
  });

  socket.on("disconnect", () => {
    const room = findRoomByPlayer(socket.id);
    if (!room) return;
    room.players.delete(socket.id);
    if (!room.players.size) rooms.delete(room.code);
    else {
      if (room.hostId === socket.id) room.hostId = room.players.keys().next().value;
      if (room.phase === "spinning") room.phase = "lobby";
      room.message = "A player disconnected. The room remains open for the team.";
      emitRoom(room);
    }
  });
});

server.listen(PORT, () => console.log(`Ultimate League Slots listening on ${PORT}`));