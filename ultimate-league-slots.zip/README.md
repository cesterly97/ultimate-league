# Ultimate League Slots — multiplayer prototype

A mobile-friendly, browser-based cooperative slot game. It includes solo mode, room creation/joining, 2–8 player rooms, host-controlled contributions and payout percentages, and server-calculated spin outcomes. It uses simulated credits only.

## Game rules

- Every player begins with 1,000 demo credits per browser session.
- Solo bets are 1–100 credits. Three matching symbols pay the symbol multiplier ×5; two matching symbols pay the symbol multiplier; otherwise the payout is zero.
- Team rooms support 2–8 players. Each player contributes 1–100 credits per spin.
- The host configures payout shares; whole-number shares must total exactly 100%.
- Team spin is enabled only for the host and only when at least two players are in the room.
- The server deducts all contributions before resolving the spin. It calculates one team payout from the total wager and allocates the payout according to agreed shares. Any rounding remainder goes to the host so all credits are accounted for.
- Symbol multipliers: 🍒 ×2, 🍋 ×2, 🔔 ×3, 💎 ×5, 7️⃣ ×10, 👑 ×20. Three of a kind pays 5× the symbol's multiplier.
- No real-money deposits, cash value, or cash prizes.

## Run locally

Requires Node.js 20 or newer.

```bash
npm install
npm start
```

Open `http://localhost:3000` in a browser. To test multiplayer locally, open a second browser or device on the same network and use the computer's LAN IP address, e.g. `http://192.168.1.10:3000`. Both devices must be able to reach the host computer.

## Deploy publicly with Render

1. Create a GitHub repository and upload this folder's contents.
2. In Render, choose **New → Web Service** and connect that repository.
3. Set **Build Command** to `npm install`.
4. Set **Start Command** to `npm start`.
5. Choose a Node environment and deploy.
6. Open the public `https://...onrender.com` URL Render gives you. Test creating a room on one device and joining from a second device/browser.

The app binds to `process.env.PORT` and uses Socket.IO/WebSockets for live room updates. Confirm the hosting provider supports WebSockets.

## Prototype limitations — fix before production

- Rooms and demo wallets are stored in server memory and reset when the process restarts. Use Redis or a database for durable state and horizontally scaled Socket.IO deployments.
- This is a functional prototype, not a production gambling platform. Add authentication, rate limiting, abuse controls, persistence, audit logs, monitoring, and automated tests before a public launch.
- The in-memory wallet is keyed by transient socket ID; reconnecting creates a new demo wallet. A production system must use authenticated user IDs.
- Random outcomes use `Math.random`; production games involving prizes need a reviewed RNG and appropriate independent testing.
- No real-money wagering, deposits, withdrawals, or prizes are implemented. Real-money functionality requires legal review, licensing, age/identity checks, geofencing, responsible-play controls, payments compliance, and jurisdiction-specific approvals.
